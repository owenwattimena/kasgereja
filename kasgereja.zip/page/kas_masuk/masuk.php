﻿<div class="row mt-4">
    <div class="col">
                        <form method="post" class="form-inline">
                            <input type="date" name="tgl_mulai" class="form-control">
                            <input type="date" name="tgl_selesai "class="form-control ml-3">
                            <button type="submit" name="filter_tgl "class="btn btn-info ml-3">Filter</button>
                        </form>
                        </div>
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                             DATA KAS MASUK
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kode</th>
                                            <th>Tanggal</th>
                                            <th>Keterangan</th>
                                            <th>Jumlah</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        if(isset($_POST['filter_tgl'])){
                                            $mulai = $_POST['tgl_mulai'];
                                            $selesai = $_POST['tgl_selesai'];
                                            $ambildata = mysql_query("select * from kas where jenis = 'masuk' and tgl BETWEEN '$mulai' and DATE_ADD('$selesai',INTERVAL 1 DAY)");
                                        } else{
                                            $sql = $koneksi-> query("select * from kas where jenis = 'masuk'");
                                        }

                                        $no = 1;

                                        while ($data=$sql-> fetch_assoc()){

                                        ?>


                                        <tr class="odd gradeX">
                                            <td><?php echo $no++ ?></td>
                                            <td><?php echo $data['kode']; ?></td>
                                            <td><?php echo date('d F Y', strtotime($data['tgl'])); ?></td>
                                            <td><?php echo $data['keterangan']; ?></td>
                                            <td align="right"><?php echo number_format($data['jumlah']).",-"; ?></td>
                                            <td>
                                                <a id="edit_data" data-toggle="modal" data-target="#edit" data-id="<?php echo $data['kode'] ?>" data-keterangan="<?php echo $data['keterangan'] ?>" data-tgl="<?php echo $data['tgl'] ?>" data-jml="<?php echo $data['jumlah'] ?>" class="btn btn-info"><i class="fa fa-edit"></i>Edit</a>

                                                <a onclick="return confirm('Yakin Akan Menghapus Data Ini....????')" href="?page=masuk&aksi=hapus&id= <?php echo $data['kode']; ?>" class="btn btn-danger"><i class="fa fa-trash"></i>Hapus</a>
                                            </td>
                                        </tr>

                                        <?php
                                            $total=$total+$data['jumlah'];
                                            }

                                        ?>

                                    </tbody>

                                        <tr>
                                            <th colspan="4" style="text-align: center; font-size: 20px">Total Kas Masuk</th>
                                            <th style="text-align: right; font-size: 17px"><?php echo"Rp." .number_format($total).",-";?></th>
                                        </tr>

                                </table>
                            </div>

                        <!--halaman tambah data-->

                        <div class="panel-body">
                            <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal">
                              Tambah Data
                            </button>

                            <a href="./laporan/laporan_kasmasuk.php" target="blank" class="btn btn-default" style="margin-top: 0px; height: 45px; width: 120px; font-size: 20px;"><i class="fa fa-print"></i> Cetak</a>

                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Form Tambah Data</h4>
                                        </div>
                                        <div class="modal-body">

                                          <form role="form" method="POST">

                                            <div class="form-group">
                                                    <label>Kode</label>
                                                    <input class="form-control"name="kode" placeholder="Input Kode" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Keterangan</label>
                                                    <input class="form-control"name="keterangan" placeholder="Keterangan" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Tanggal</label>
                                                    <input class="form-control" type="date" name="tgl" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Jumlah</label>
                                                    <input class="form-control" type="number" name="jml" />
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                        <?php
                            if (isset($_POST['simpan'])) {

                                $kode = $_POST['kode'];
                                $keterangan = $_POST['keterangan'];
                                $tgl = $_POST['tgl'];
                                $jml = $_POST['jml'];

                                $sql = $koneksi-> query ("insert into kas (kode, keterangan, tgl, jumlah, jenis, keluar)values('$kode', '$keterangan', '$tgl', '$jml', 'masuk', 0)");

                                if ($sql){
                                    ?>
                                        <script type="text/javascript">
                                            alert("Simpan Data Berhasil");
                                            window.location.href="?page=masuk";
                                        </script>
                                    <?php 
                                }
                            }
                        ?>

                      <!--Akhir halaman tambah data-->

                      <!--halaman ubah-->

                      <div class="panel-body">
                            <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Form Edit Data</h4>
                                        </div>
                                        <div class="modal-body" id="modal_edit">

                                          <form role="form" method="POST">

                                            <div class="form-group">
                                                    <label>Kode</label>
                                                    <input class="form-control"name="kode" placeholder="Input Kode" id="kode" readonly />
                                            </div>

                                            <div class="form-group">
                                                    <label>Keterangan</label>
                                                    <input class="form-control"name="keterangan" placeholder="Keterangan" id="keterangan" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Tanggal</label>
                                                    <input class="form-control" type="date" name="tgl" id="tgl" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Jumlah</label>
                                                    <input class="form-control" type="number" name="jml" id="jml" />
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <input type="submit" name="ubah" value="Ubah" class="btn btn-primary">
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                      <script src="assets/js/jquery-1.10.2.js"></script>
                      <script type="text/javascript">
                          $(document).on("click", "#edit_data", function(){

                             var kode = $(this).data('id');
                             var keterangan = $(this).data('keterangan');
                             var tgl = $(this).data('tgl');
                             var jml = $(this).data('jml');

                             $("#modal_edit #kode").val(kode);
                             $("#modal_edit #keterangan").val(keterangan);
                             $("#modal_edit #tgl").val(tgl);
                             $("#modal_edit #jml").val(jml);
                          })
                      </script>

                      <?php 

                        if (isset($_POST['ubah'])) {

                            $kode = $_POST['kode'];
                            $keterangan = $_POST['keterangan'];
                            $tgl = $_POST['tgl'];
                            $jml = $_POST['jml'];

                            $sql = $koneksi-> query ("update kas set keterangan = '$keterangan', tgl = '$tgl', jumlah = '$jml', jenis='masuk', keluar=0 where kode='$kode' ");

                            if ($sql){
                                    ?>
                                        <script type="text/javascript">
                                            alert("Ubah Data Berhasil");
                                            window.location.href="?page=masuk";
                                        </script>
                                    <?php 
                            } 
                        }
                    ?>
                      <!--Akhir halaman ubah-->

                    </div>    
                </div>
</div>

                
  <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
             <!-- JQUERY SCRIPTS -->
              <script src="assets/js/jquery-1.10.2.js"></script>
                <!-- BOOTSTRAP SCRIPTS -->
              <script src="assets/js/bootstrap.min.js"></script>
              <!-- METISMENU SCRIPTS -->
              <script src="assets/js/jquery.metisMenu.js"></script>
               <!-- DATA TABLE SCRIPTS -->
              <script src="assets/js/dataTables/jquery.dataTables.js"></script>
              <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
              <script>
                      $(document).ready(function () {
                          $('#dataTables-example').dataTable();
                      });
              </script>
                   <!-- CUSTOM SCRIPTS -->
              <script src="assets/js/custom.js"></script>