<div class="row">
    <div class="col-2">
                            <label class="label">Nama Barang</label>
                            <input id="nama_brg" type="text" class="form-control" placeholder="Nama Barang">
                        </div>
                        <div class="col-2 float-sm-right">
                            <button class="btn btn-sm btn-outline-primary form-control" onclick="filter_search()">CARI</button>
                        </div>
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                             DATA ASET JEMAAT
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kode</th>
                                            <th>Nama Barang</th>
                                            <th>Jumlah</th>
                                            <th>Thn Perolehan</th>
                                            <th>Harga</th>
                                            <th>Kondisi</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php
                                        $no = 1;

                                        $sql = $koneksi-> query("select * from aset");
                                        while ($data=$sql-> fetch_assoc()){

                                        ?>


                                        <tr class="odd gradeX">
                                            <td><?php echo $no++ ?></td>
                                            <td><?php echo $data['kode']; ?></td>
                                            <td><?php echo $data['nama_brg']; ?></td>
                                            <td><?php echo number_format($data['jumlah'])."  Bh"; ?></td>
                                            <td><?php echo $data['thn_perolehan']; ?></td>
                                            <td align="right"><?php echo number_format($data['harga']).",-"; ?></td>
                                            <td><?php echo $data['kondisi']; ?></td>
                                            <td>
                                                <a id="edit_data" data-toggle="modal" data-target="#edit" data-id="<?php echo $data['kode'] ?>" data-nama_brg="<?php echo $data['nama_brg'] ?>" data-jumlah="<?php echo $data['jumlah'] ?>" data-thn_perolehan="<?php echo $data['thn_perolehan'] ?>" data-jml="<?php echo $data['harga'] ?>" data-kondisi="<?php echo $data['kondisi'] ?>" class="btn btn-info"><i class="fa fa-edit"></i>Edit</a>

                                                <a onclick="return confirm('Yakin Akan Menghapus Data Ini....????')" href="?page=aset&aksi=hapus&id= <?php echo $data['kode']; ?>" class="btn btn-danger"><i class="fa fa-trash"></i>Hapus</a>
                                            </td>
                                        </tr>

                                        <?php
                                            $total=$total+$data['harga'];
                                            }

                                        ?>

                                    </tbody>

                                      <tr>
                                            <th colspan="5" style="text-align: center; font-size: 20px">Total Harga</th>
                                            <th style="text-align: right; font-size: 17px"><?php echo"Rp." .number_format($total).",-";?></th>
                                    </tr>

                                </table>
                            </div>

                        <!--halaman tambah data-->

                        <div class="panel-body">
                            <button class="btn btn-success btn-lg" data-toggle="modal" data-target="#myModal">
                              Tambah Data
                            </button>

                             <a href="./laporan/laporan_aset.php" target="blank" class="btn btn-default" style="margin-top: 0px; height: 45px; width: 120px; font-size: 20px;"><i class="fa fa-print"></i> Cetak</a>

                            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Form Tambah Data Aset</h4>
                                        </div>
                                        <div class="modal-body">

                                          <form role="form" method="POST">

                                            <div class="form-group">
                                                    <label>Kode</label>
                                                    <input class="form-control"name="kode" placeholder="Input Kode" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Nama Barang</label>
                                                    <input class="form-control"name="nama_brg" placeholder="Nama Barang" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Jumlah</label>
                                                    <input class="form-control" type="number" name="jumlah" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Tahun Perolehan</label>
                                                    <input class="form-control" type="text" name="thn_perolehan" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Harga</label>
                                                    <input class="form-control" type="number" name="jml" />
                                            </div>

                                             <div class="form-group">
                                                    <label>Kondisi</label>
                                                    <input class="form-control"name="kondisi" placeholder="kondisi" />
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <input type="submit" name="simpan" value="Simpan" class="btn btn-primary">
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                        <?php
                            if (isset($_POST['simpan'])) {

                                $kode = $_POST['kode'];
                                $nama_brg = $_POST['nama_brg'];
                                $jumlah = $_POST['jumlah'];
                                $thn_perolehan = $_POST['thn_perolehan'];
                                $jml = $_POST['jml'];
                                $kondisi = $_POST['kondisi'];

                                $sql = $koneksi-> query ("insert into aset (kode, nama_brg, jumlah, thn_perolehan, harga, kondisi)values('$kode', '$nama_brg', '$jumlah', '$thn_perolehan', '$jml', '$kondisi')");

                                if ($sql){
                                    ?>
                                        <script type="text/javascript">
                                            alert("Simpan Data Berhasil");
                                            window.location.href="?page=aset";
                                        </script>
                                    <?php 
                                }
                            }
                        ?>

                      <!--Akhir halaman tambah data-->

                      <!--halaman ubah-->

                      <div class="panel-body">
                            <div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title" id="myModalLabel">Form Edit Data Aset</h4>
                                        </div>
                                        <div class="modal-body" id="modal_edit">

                                          <form role="form" method="POST">

                                            <div class="form-group">
                                                    <label>Kode</label>
                                                    <input class="form-control"name="kode" placeholder="Input Kode" id="kode" readonly />
                                            </div>

                                            <div class="form-group">
                                                    <label>Nama Barang</label>
                                                    <input class="form-control"name="nama_brg" placeholder="Nama Barang" id="nama_brg" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Jumlah</label>
                                                    <input class="form-control" type="number" name="jumlah" id="jumlah" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Tahun Perolehan</label>
                                                    <input class="form-control" type="text" name="thn_perolehan" id="thn_perolehan" />
                                            </div>

                                            <div class="form-group">
                                                    <label>Harga</label>
                                                    <input class="form-control" type="number" name="jml" id="jml" />
                                            </div>


                                            <div class="form-group">
                                                    <label>Kondisi</label>
                                                    <input class="form-control"name="kondisi" placeholder="Kondisi" id="kondisi" />
                                            </div>

                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                            <input type="submit" name="ubah" value="Ubah" class="btn btn-primary">
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                      <script src="assets/js/jquery-1.10.2.js"></script>
                      <script type="text/javascript">
                          $(document).on("click", "#edit_data", function(){

                             var kode = $(this).data('id');
                             var nama_brg = $(this).data('nama_brg');
                             var jumlah = $(this).data('jumlah');
                             var thn_perolehan = $(this).data('thn_perolehan');
                             var jml = $(this).data('jml');
                             var kondisi = $(this).data('kondisi');

                             $("#modal_edit #kode").val(kode);
                             $("#modal_edit #nama_brg").val(nama_brg);
                             $("#modal_edit #jumlah").val(jumlah);
                             $("#modal_edit #thn_perolehan").val(thn_perolehan);
                             $("#modal_edit #jml").val(jml);
                             $("#modal_edit #kondisi").val(kondisi);
                          })
                      </script>

                      <?php 

                        if (isset($_POST['ubah'])) {

                            $kode = $_POST['kode'];
                            $nama_brg = $_POST['nama_brg'];
                            $jumlah = $_POST['jumlah'];
                            $thn_perolehan = $_POST['thn_perolehan'];
                            $jml = $_POST['jml'];
                            $kondisi = $_POST['kondisi'];

                            $sql = $koneksi-> query ("update aset set nama_brg = '$nama_brg', jumlah = '$jumlah', thn_perolehan = '$thn_perolehan', harga = '$jml', kondisi = '$kondisi' where kode='$kode' ");

                            if ($sql){
                                    ?>
                                        <script type="text/javascript">
                                            alert("Ubah Data Berhasil");
                                            window.location.href="?page=aset";
                                        </script>
                                    <?php 
                            } 
                        }
                    ?>
                      <!--Akhir halaman ubah-->

                    </div>    
                </div>
</div>

                
  <!-- SCRIPTS -AT THE BOTOM TO REDUCE THE LOAD TIME-->
             <!-- JQUERY SCRIPTS -->
              <script src="assets/js/jquery-1.10.2.js"></script>
                <!-- BOOTSTRAP SCRIPTS -->
              <script src="assets/js/bootstrap.min.js"></script>
              <!-- METISMENU SCRIPTS -->
              <script src="assets/js/jquery.metisMenu.js"></script>
               <!-- DATA TABLE SCRIPTS -->
              <script src="assets/js/dataTables/jquery.dataTables.js"></script>
              <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
              <script>
                      $(document).ready(function () {
                          $('#dataTables-example').dataTable();
                      });
              </script>
                   <!-- CUSTOM SCRIPTS -->
              <script src="assets/js/custom.js"></script>