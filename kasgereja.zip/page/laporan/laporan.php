<h1 align="center"><b>LAPORAN KAS & ASET JEMAAT ELOHIM LATTA<b></h1>
<br>
<br>
<br>
	<div align="center">
    <a href="./laporan/laporan_kasmasuk.php" target="blank" class="btn btn-default" style="margin-top: 0px; height: 45px; width: 400px; font-size: 20px;"><i class="fa fa-print"></i> Laporan Kas Masuk</a>

    <a href="./laporan/laporan_kaskeluar.php" target="blank" class="btn btn-default" style="margin-top: 0px; height: 45px; width: 400px; font-size: 20px;"><i class="fa fa-print"></i> Laporan Kas Keluar</a>
    </div>
<br>
    <div align="center">
    <a href="./laporan/laporan_rekapitulasi.php" target="blank" class="btn btn-default" style="margin-top: 0px; height: 45px; width: 400px; font-size: 20px;"><i class="fa fa-print"></i> Laporan Rekapitulasi Kas</a>

    <a href="./laporan/laporan_aset.php" target="blank" class="btn btn-default" style="margin-top: 0px; height: 45px; width: 400px; font-size: 20px;"><i class="fa fa-print"></i> Laporan Aset</a>    
    </div>    
